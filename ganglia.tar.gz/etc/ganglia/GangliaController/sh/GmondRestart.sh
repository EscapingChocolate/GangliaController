#!/bin/sh
echo 2Bv1^b6W5E|sudo -S /etc/init.d/ganglia-monitor restart

