#!/bin/sh
srcpath=$1
dstpath=$2
echo 2Bv1^b6W5E|sudo -S mv ${srcpath} ${dstpath}
